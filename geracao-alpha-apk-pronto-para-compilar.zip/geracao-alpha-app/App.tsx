import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, ScrollView, Pressable, TextInput,
  Switch, StyleSheet, Alert, StatusBar
} from "react-native";

type Feature = { id: string; name: string; category: string; description: string; active: boolean; custom?: boolean };
type Tab = "Início" | "Marketplace" | "Comunidade" | "Negócios" | "Admin";

const initialFeatures: Feature[] = [
  { id: "marketplace", name: "Marketplace", category: "Comércio", description: "Compra e venda de produtos e serviços.", active: true },
  { id: "social", name: "Rede Social", category: "Comunidade", description: "Publicações, comentários e seguidores.", active: true },
  { id: "business", name: "Negócios", category: "Empresas", description: "Gestão de empresas, serviços e clientes.", active: true },
  { id: "services", name: "Serviços", category: "Serviços", description: "Descobrir e contratar serviços.", active: true },
  { id: "messages", name: "Mensagens", category: "Comunicação", description: "Conversas entre utilizadores.", active: true },
  { id: "payments", name: "Pagamentos", category: "Financeiro", description: "Área preparada para integrar pagamentos.", active: false },
  { id: "ads", name: "Publicidade", category: "Marketing", description: "Espaços promocionais para empresas.", active: false },
  { id: "premium", name: "Funcionalidades Premium", category: "Planos", description: "Vantagens adicionais para assinantes.", active: false },
];

const blue = "#0866E8";
const navy = "#082B5C";
const pale = "#F2F7FF";

export default function App() {
  const [tab, setTab] = useState<Tab>("Início");
  const [features, setFeatures] = useState<Feature[]>(initialFeatures);
  const [search, setSearch] = useState("");
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newCategory, setNewCategory] = useState("Personalizada");
  const [showAdd, setShowAdd] = useState(false);

  const activeCount = features.filter(f => f.active).length;
  const visibleFeatures = useMemo(
    () => features.filter(f => (f.name + " " + f.category + " " + f.description).toLowerCase().includes(search.toLowerCase())),
    [features, search]
  );

  function toggleFeature(id: string, active: boolean) {
    setFeatures(current => current.map(f => f.id === id ? { ...f, active } : f));
  }

  function addFeature() {
    if (!newName.trim() || !newDescription.trim()) {
      Alert.alert("Campos obrigatórios", "Preenche o nome e a descrição da funcionalidade.");
      return;
    }
    const item: Feature = {
      id: `custom-${Date.now()}`, name: newName.trim(), description: newDescription.trim(),
      category: newCategory.trim() || "Personalizada", active: true, custom: true
    };
    setFeatures(current => [item, ...current]);
    setNewName(""); setNewDescription(""); setNewCategory("Personalizada"); setShowAdd(false);
    Alert.alert("Funcionalidade adicionada", "Foi adicionada a esta demonstração local.");
  }

  function removeFeature(id: string) {
    Alert.alert("Eliminar funcionalidade?", "Esta ação remove a funcionalidade desta demonstração local.", [
      { text: "Cancelar", style: "cancel" },
      { text: "Eliminar", style: "destructive", onPress: () => setFeatures(current => current.filter(f => f.id !== id)) }
    ]);
  }

  const tabs: Tab[] = ["Início", "Marketplace", "Comunidade", "Negócios", "Admin"];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={navy} />
      <View style={styles.header}>
        <View style={styles.brandMark}><Text style={styles.brandMarkText}>GA</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>Geração Alpha</Text>
          <Text style={styles.tagline}>Conecta · Compra · Vende · Cresce</Text>
        </View>
        <View style={styles.avatar}><Text style={styles.avatarText}>A</Text></View>
      </View>

      <ScrollView style={styles.body} contentContainerStyle={styles.bodyContent} keyboardShouldPersistTaps="handled">
        {tab === "Admin" ? (
          <>
            <Text style={styles.eyebrow}>ÁREA RESTRITA · PROTÓTIPO</Text>
            <Text style={styles.pageTitle}>Gestão de funcionalidades</Text>
            <Text style={styles.subtitle}>Ativa, desativa e adiciona módulos à demonstração do Geração Alpha.</Text>
            <View style={styles.statsRow}>
              <Stat label="Funcionalidades" value={String(features.length)} />
              <Stat label="Ativas" value={String(activeCount)} />
              <Stat label="Personalizadas" value={String(features.filter(f => f.custom).length)} />
            </View>
            <TextInput value={search} onChangeText={setSearch} placeholder="Pesquisar funcionalidades..." placeholderTextColor="#7A8BA8" style={styles.input} />
            <Pressable style={styles.primaryButton} onPress={() => setShowAdd(v => !v)}>
              <Text style={styles.primaryButtonText}>{showAdd ? "Fechar formulário" : "+ Adicionar funcionalidade"}</Text>
            </Pressable>
            {showAdd && (
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Nova funcionalidade</Text>
                <TextInput value={newName} onChangeText={setNewName} placeholder="Nome da funcionalidade" placeholderTextColor="#7A8BA8" style={styles.input} />
                <TextInput value={newDescription} onChangeText={setNewDescription} placeholder="Descrição" placeholderTextColor="#7A8BA8" multiline style={[styles.input, styles.multiline]} />
                <TextInput value={newCategory} onChangeText={setNewCategory} placeholder="Categoria" placeholderTextColor="#7A8BA8" style={styles.input} />
                <Pressable style={styles.primaryButton} onPress={addFeature}><Text style={styles.primaryButtonText}>Guardar funcionalidade</Text></Pressable>
              </View>
            )}
            {visibleFeatures.map(feature => (
              <View key={feature.id} style={styles.featureCard}>
                <View style={styles.featureTop}>
                  <View style={[styles.featureIcon, { backgroundColor: feature.active ? "#E5F0FF" : "#EEF1F6" }]}>
                    <Text style={{ fontSize: 18 }}>{feature.custom ? "✦" : feature.name === "Marketplace" ? "🛍️" : feature.name === "Rede Social" ? "👥" : feature.name === "Negócios" ? "💼" : "⚙️"}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.featureName}>{feature.name}</Text>
                    <Text style={styles.featureCategory}>{feature.category}{feature.custom ? " · Personalizada" : ""}</Text>
                  </View>
                  <Switch value={feature.active} onValueChange={v => toggleFeature(feature.id, v)} trackColor={{ false: "#C9D2E0", true: "#8BB9FF" }} thumbColor={feature.active ? blue : "#F5F7FA"} />
                </View>
                <Text style={styles.featureDescription}>{feature.description}</Text>
                <View style={styles.featureActions}>
                  <Text style={[styles.status, feature.active ? styles.statusActive : styles.statusInactive]}>{feature.active ? "ATIVA" : "INATIVA"}</Text>
                  <Pressable onPress={() => Alert.alert(feature.name, feature.description)}><Text style={styles.actionText}>Detalhes</Text></Pressable>
                  {feature.custom && <Pressable onPress={() => removeFeature(feature.id)}><Text style={styles.deleteText}>Eliminar</Text></Pressable>}
                </View>
              </View>
            ))}
            <View style={styles.notice}><Text style={styles.noticeTitle}>Importante</Text><Text style={styles.noticeText}>Esta gestão é local e serve como protótipo visual. Para controlar a aplicação real, é necessário ligar uma API/base de dados e proteger as permissões de administrador no servidor.</Text></View>
          </>
        ) : tab === "Início" ? (
          <>
            <Text style={styles.greeting}>Olá! 👋</Text>
            <Text style={styles.pageTitle}>Bem-vindo à Geração Alpha</Text>
            <Text style={styles.subtitle}>O teu mundo digital para conectar pessoas, descobrir serviços e fazer crescer negócios.</Text>
            <View style={styles.hero}>
              <Text style={styles.heroSmall}>CONECTA · COMPRA · VENDE · CRESCE</Text>
              <Text style={styles.heroTitle}>Tudo começa aqui.</Text>
              <Text style={styles.heroBody}>Uma comunidade para pessoas, vendedores e empresas.</Text>
              <Pressable style={styles.heroButton} onPress={() => setTab("Marketplace")}><Text style={styles.heroButtonText}>Explorar marketplace →</Text></Pressable>
            </View>
            <Text style={styles.sectionTitle}>Explora a plataforma</Text>
            <View style={styles.grid}>
              <FeatureTile icon="🛍️" title="Marketplace" body="Produtos e serviços" onPress={() => setTab("Marketplace")} />
              <FeatureTile icon="👥" title="Comunidade" body="Publica e conecta-te" onPress={() => setTab("Comunidade")} />
              <FeatureTile icon="💼" title="Negócios" body="Faz crescer a tua marca" onPress={() => setTab("Negócios")} />
              <FeatureTile icon="⚙️" title="Administração" body="Gerir módulos" onPress={() => setTab("Admin")} />
            </View>
            <View style={styles.notice}><Text style={styles.noticeTitle}>Primeira versão</Text><Text style={styles.noticeText}>Este projeto é a base inicial da aplicação. Contas reais, compras, mensagens e pagamentos precisam de backend e integrações antes de serem lançados ao público.</Text></View>
          </>
        ) : (
          <>
            <Text style={styles.eyebrow}>GERAÇÃO ALPHA</Text>
            <Text style={styles.pageTitle}>{tab}</Text>
            <Text style={styles.subtitle}>{tab === "Marketplace" ? "Descobre produtos e serviços da comunidade." : tab === "Comunidade" ? "Partilha ideias e liga-te a outras pessoas." : "Ferramentas para vendedores e empresas."}</Text>
            <View style={styles.emptyCard}>
              <Text style={styles.emptyIcon}>{tab === "Marketplace" ? "🛍️" : tab === "Comunidade" ? "👥" : "💼"}</Text>
              <Text style={styles.cardTitle}>Módulo em preparação</Text>
              <Text style={styles.featureDescription}>A estrutura visual está criada. Para disponibilizar esta funcionalidade a utilizadores reais, falta implementar os dados, as permissões e os serviços correspondentes.</Text>
              <Pressable style={styles.primaryButton} onPress={() => setTab("Admin")}><Text style={styles.primaryButtonText}>Abrir gestão de funcionalidades</Text></Pressable>
            </View>
          </>
        )}
      </ScrollView>

      <View style={styles.tabBar}>
        {tabs.map(t => (
          <Pressable key={t} style={styles.tabItem} onPress={() => setTab(t)}>
            <Text style={[styles.tabIcon, tab === t && styles.tabIconActive]}>{t === "Início" ? "⌂" : t === "Marketplace" ? "▣" : t === "Comunidade" ? "♧" : t === "Negócios" ? "▤" : "⚙"}</Text>
            <Text style={[styles.tabLabel, tab === t && styles.tabLabelActive]}>{t}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>;
}
function FeatureTile({ icon, title, body, onPress }: { icon: string; title: string; body: string; onPress: () => void }) {
  return <Pressable style={styles.tile} onPress={onPress}><Text style={styles.tileIcon}>{icon}</Text><Text style={styles.tileTitle}>{title}</Text><Text style={styles.tileBody}>{body}</Text></Pressable>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FFFFFF" },
  header: { backgroundColor: navy, paddingHorizontal: 18, paddingVertical: 14, flexDirection: "row", alignItems: "center", gap: 11 },
  brandMark: { width: 42, height: 42, borderRadius: 13, backgroundColor: "#20C7F5", alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: navy, fontSize: 16, fontWeight: "900" },
  brand: { color: "#FFFFFF", fontWeight: "800", fontSize: 17 },
  tagline: { color: "#C7DFFF", fontSize: 10, marginTop: 3 },
  avatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: "#D9E9FF", alignItems: "center", justifyContent: "center" },
  avatarText: { color: navy, fontWeight: "800" },
  body: { flex: 1, backgroundColor: "#F5F8FD" },
  bodyContent: { padding: 18, paddingBottom: 30 },
  eyebrow: { color: blue, fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginBottom: 8 },
  greeting: { color: blue, fontSize: 15, fontWeight: "700", marginBottom: 4 },
  pageTitle: { color: navy, fontSize: 24, fontWeight: "900", marginBottom: 7 },
  subtitle: { color: "#63748E", fontSize: 13, lineHeight: 19, marginBottom: 17 },
  hero: { backgroundColor: blue, borderRadius: 22, padding: 22, marginBottom: 22 },
  heroSmall: { color: "#C8E7FF", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  heroTitle: { color: "#FFFFFF", fontSize: 27, fontWeight: "900", marginTop: 13 },
  heroBody: { color: "#E7F2FF", fontSize: 13, lineHeight: 19, marginTop: 7, maxWidth: 270 },
  heroButton: { alignSelf: "flex-start", backgroundColor: "#FFFFFF", borderRadius: 12, paddingVertical: 11, paddingHorizontal: 15, marginTop: 18 },
  heroButtonText: { color: blue, fontWeight: "800", fontSize: 12 },
  sectionTitle: { color: navy, fontSize: 17, fontWeight: "800", marginBottom: 12 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 11 },
  tile: { width: "48%", flexGrow: 1, backgroundColor: "#FFFFFF", borderRadius: 17, padding: 15, borderWidth: 1, borderColor: "#E2EBF7", minHeight: 125 },
  tileIcon: { fontSize: 25, marginBottom: 12 },
  tileTitle: { color: navy, fontSize: 14, fontWeight: "800" },
  tileBody: { color: "#6D7D94", fontSize: 11, marginTop: 5 },
  statsRow: { flexDirection: "row", gap: 8, marginBottom: 14 },
  stat: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 14, paddingVertical: 13, paddingHorizontal: 8, borderWidth: 1, borderColor: "#E0EAF8" },
  statValue: { color: blue, fontSize: 22, fontWeight: "900", textAlign: "center" },
  statLabel: { color: "#6D7D94", fontSize: 9, textAlign: "center", marginTop: 4 },
  input: { backgroundColor: "#FFFFFF", borderColor: "#D9E5F4", borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 12, color: navy, fontSize: 13, marginBottom: 10 },
  multiline: { minHeight: 78, textAlignVertical: "top" },
  primaryButton: { backgroundColor: blue, paddingVertical: 13, paddingHorizontal: 15, borderRadius: 12, alignItems: "center", marginBottom: 13 },
  primaryButtonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 13 },
  card: { backgroundColor: "#FFFFFF", borderRadius: 17, padding: 15, borderWidth: 1, borderColor: "#DFE9F6", marginBottom: 13 },
  cardTitle: { color: navy, fontSize: 15, fontWeight: "800", marginBottom: 10 },
  featureCard: { backgroundColor: "#FFFFFF", borderRadius: 15, padding: 14, borderWidth: 1, borderColor: "#E1EAF6", marginTop: 10 },
  featureTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  featureIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  featureName: { color: navy, fontSize: 14, fontWeight: "800" },
  featureCategory: { color: "#7B8AA1", fontSize: 11, marginTop: 3 },
  featureDescription: { color: "#62738C", fontSize: 12, lineHeight: 18, marginTop: 10 },
  featureActions: { flexDirection: "row", alignItems: "center", gap: 16, marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: "#EEF2F8" },
  status: { fontSize: 9, fontWeight: "900", letterSpacing: 0.6 },
  statusActive: { color: "#0D9B63" },
  statusInactive: { color: "#8A96A8" },
  actionText: { color: blue, fontWeight: "700", fontSize: 11 },
  deleteText: { color: "#D72F44", fontWeight: "700", fontSize: 11 },
  notice: { backgroundColor: "#EAF3FF", borderColor: "#D4E6FF", borderWidth: 1, borderRadius: 14, padding: 14, marginTop: 18 },
  noticeTitle: { color: navy, fontSize: 12, fontWeight: "900", marginBottom: 5 },
  noticeText: { color: "#526B8C", fontSize: 11, lineHeight: 17 },
  emptyCard: { backgroundColor: "#FFFFFF", borderRadius: 18, padding: 20, borderColor: "#E0EAF8", borderWidth: 1, alignItems: "flex-start" },
  emptyIcon: { fontSize: 35, marginBottom: 12 },
  tabBar: { flexDirection: "row", justifyContent: "space-around", paddingTop: 9, paddingBottom: 10, backgroundColor: "#FFFFFF", borderTopWidth: 1, borderTopColor: "#E0E8F3" },
  tabItem: { alignItems: "center", minWidth: 55 },
  tabIcon: { color: "#7A8AA3", fontSize: 22, fontWeight: "800" },
  tabIconActive: { color: blue },
  tabLabel: { color: "#7A8AA3", fontSize: 9, marginTop: 3 },
  tabLabelActive: { color: blue, fontWeight: "800" }
});
