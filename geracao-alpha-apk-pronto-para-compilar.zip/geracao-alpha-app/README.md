# Geração Alpha — projeto Expo preparado para gerar APK

Este projeto contém a primeira versão móvel em Expo/React Native, com interface azul e branca, navegação e um painel de demonstração para gerir módulos localmente.

## Estado real do projeto

**Preparado para iniciar uma compilação APK com EAS Build**, depois de configurar a conta Expo e validar a instalação das dependências. O APK ainda não foi compilado nem testado em dispositivo nesta sessão.

Incluído:
- Aplicação Expo + React Native + TypeScript.
- Configuração Android e iOS.
- `eas.json` com perfil `preview` que solicita um APK instalável.
- Ecrãs de início, marketplace, comunidade, negócios e administração.
- Pesquisa, ativar/desativar módulos e adicionar/eliminar módulos na sessão local.

Ainda necessário antes de lançamento público:
- Ligar backend/base de dados para guardar alterações e dados dos utilizadores.
- Implementar autenticação real e autorização administrativa no servidor.
- Implementar e testar funcionalidades reais de marketplace, mensagens, pedidos, pagamentos, comissões, anúncios e subscrições.
- Substituir `SUBSTITUIR_PELO_PROJECT_ID_DO_EAS` pelo ID atribuído pelo EAS, executando `eas init`.
- Criar ícones e ecrãs de abertura finais, testar em dispositivos e rever os identificadores da aplicação.
- Para publicação na App Store, configurar conta Apple Developer e o perfil de compilação iOS.

## Gerar o APK com EAS Build

Requer Node.js/npm num ambiente de desenvolvimento e uma conta Expo. Se só tiveres Android, podes fazer esta configuração num ambiente de desenvolvimento na nuvem que permita executar comandos de terminal.

1. Extrai este ZIP.
2. No terminal, entra na pasta do projeto.
3. Executa:
   ```bash
   npm install
   npx expo-doctor
   npx eas-cli@latest login
   npx eas-cli@latest init
   npx eas-cli@latest build --platform android --profile preview
   ```
4. Segue as perguntas do EAS e espera que a compilação na nuvem termine.
5. Abre o link de resultado no telemóvel Android e descarrega o APK.
6. Autoriza a instalação a partir dessa origem, se o Android solicitar, e instala o APK.

Para gerar um pacote destinado à Google Play:
```bash
npx eas-cli@latest build --platform android --profile production
```

## Importante
O perfil `preview` está configurado para produzir APK. Uma configuração de build não significa que o APK já exista: o ficheiro só será criado depois de a compilação remota terminar com sucesso. O projeto não deve ser anunciado como pronto para produção até o backend, segurança, dados e fluxos de negócio estarem implementados e testados.
